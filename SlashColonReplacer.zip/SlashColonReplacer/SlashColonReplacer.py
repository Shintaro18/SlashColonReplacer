#This program modifies result text data of operant house for the analysis of miniscope (e.g. replace '/' and ':' with 'tab')

# Import of module
import os, tkinter, tkinter.filedialog, tkinter.messagebox
from tkinter import filedialog as fd

#======Show file select dialog======
root = tkinter.Tk()
root.withdraw()
fTyp = [("","*")]
iDir = os.path.abspath(os.path.dirname(__file__))
#tkinter.messagebox.showinfo('Message','Select result file of operant house (.txt)')
file = tkinter.filedialog.askopenfilename(filetypes = fTyp,initialdir = iDir)
#tkinter.messagebox.showinfo('The path of the file is ...',file)

#======Load text file======
Textfile=open(file,'r')
#Textfile=open('Text.txt','r')
Text=Textfile.read()
Textfile.close()

#======Replacement======
print(str("Before"));
print(Text) #Show text before replacing
#A=Text.find('/')
#print(A)
Text=Text.replace('/',' ')  #replacing
Text=Text.replace(':',' ')
print(str("After"));
print(Text) #Show text after replacing

#======Show save dialog======
file=fd.asksaveasfilename(
    initialfile = "mydata",
    defaultextension = ".txt",
    title = "保存場所を選んでください。",
    filetypes=[("TEXT",".txt")]
)

#======Export text data======
Textfile=open(file,"w")
#Textfile=open("OutText.txt","w")
Textfile.write(Text)
Textfile.close()